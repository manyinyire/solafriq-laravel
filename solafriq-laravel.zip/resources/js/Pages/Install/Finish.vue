<template>
  <div class="installer-container">
    <h1>SolaFriq Installer - Installation Complete</h1>
    <p>Congratulations! The application has been installed successfully.</p>
    <p>You can now log in with the admin account you created.</p>
    <div class="navigation-buttons">
      <a href="/">Go to Homepage</a>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style scoped>
/* Add your styles here */
</style>
